#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <queue>
#include <cmath>
#include <stack>
#include <map>
#include <set>
#include <deque>
#include <cstring>
#include <functional>
#include <climits>
#include <list>
#include <ctime>
#include <complex>
 
#define F1(x,y,z) for(int x=y;x<z;x++)
#define F2(x,y,z) for(int x=y;x<=z;x++)
#define F3(x,y,z) for(int x=y;x>z;x--)
#define F4(x,y,z) for(int x=y;x>=z;x--)
#define pb push_back
#define LL long long
#define co complex<double>
 
#define MAX 200005
#define AMAX 1500
#define MOD 1000000007

#define f(c,d) ((1<<(c))*(d))

using namespace std;

int t,ta,tb,tc,aa,bb,cc,dd,ee,ff;
LL tx,cnt,ty;
int day=24*60*60;
int to[MAX];
LL cn[MAX];
vector<int> ca;
vector<LL> cb;
bool v[MAX];
int at[MAX];
int cfrom,cs;
LL caa;

int main(){
	freopen("in.txt","r",stdin);
	freopen("out.txt","w",stdout);
	scanf("%d",&t);
	F2(a,1,t){
		cnt=0;
		scanf("%d:%d:%d",&ta,&tb,&tc);
		aa=(ta*60+tb)*60+tc;
		scanf("%d:%d:%d",&ta,&tb,&tc);
		bb=(ta*60+tb)*60+tc;
		scanf("%d:%d:%d",&ta,&tb,&tc);
		cc=(ta*60+tb)*60+tc;
		scanf("%d:%d:%d",&ta,&tb,&tc);
		dd=(ta*60+tb)*60+tc;
		scanf("%d:%d:%d",&ta,&tb,&tc);
		ee=(ta*60+tb)*60+tc;
		scanf("%lld",&tx);
		ff=ee;
		if(cc-bb>ee){
			printf("Case #%d: -1\n",a);
			continue;
		}
		if(tx==1){
			if(ff<bb-1){
				ty=(bb-1-ff+ee-1)/ee;
				cnt+=ty;
				ff+=ty*ee;
			}
			if(ff<cc){
				ff=bb-1;
				cnt++;
				ff+=ee;
			}
			if(ff<dd-1){
				ty=(dd-1-ff+ee-1)/ee;
				cnt+=ty;
				ff+=ty*ee;
			}
			if(ff<day){
				ff=dd-1;
				cnt++;
				ff+=ee;
			}
			if(ff<day)printf("Case #%d: -1\n",a);
			else printf("Case #%d: %lld\n",a,cnt);
			continue;
		}
		if(aa+day-dd>ee){
			printf("Case #%d: -1\n",a);
			continue;
		}
		F1(b,0,day){
			to[b]=b;
			cn[b]=0;		
			if(to[b]<aa){
				to[b]=dd-1-day;
				cn[b]++;
				to[b]+=ee;
			}
			if(to[b]<bb-1){
				ty=(bb-1-to[b]+ee-1)/ee;
				cn[b]+=ty;
				to[b]+=ty*ee;
			}
			if(to[b]<cc){
				to[b]=bb-1;
				cn[b]++;
				to[b]+=ee;
			}
			if(to[b]<dd-1){
				ty=(dd-1-to[b]+ee-1)/ee;
				cn[b]+=ty;
				to[b]+=ty*ee;
			}
			if(to[b]<day){
				to[b]=dd-1;
				cn[b]++;
				to[b]+=ee;
			}
			to[b]-=day;
			//if(a==1&&b==ff)printf("%d->%d %lld\n",b,to[b],cn[b]);
			//if(a==1&&b==32399)printf("%d->%d %lld\n",b,to[b],cn[b]);
		}
		ca.clear();
		cb.clear();
		F1(b,0,day)v[b]=0;
		ca.pb(ff);
		cb.pb(0);
		at[ff]=0;
		v[ff]=1;
		while(1){
			cb.pb(cb.back()+cn[ca.back()]);
			ca.pb(to[ca.back()]);
			if(v[ca.back()]){
				cfrom=at[ca.back()];
				caa=cb.back()-cb[cfrom];
				ca.pop_back();
				cb.pop_back();
				cs=ca.size()-cfrom;
				break;		
			}
			v[ca.back()]=1;
			at[ca.back()]=ca.size()-1;
		}
		//printf("! %d %d %lld\n",cfrom,cs,caa);
		ca.pop_back();
		if(tx<cfrom)printf("Case #%d: %lld\n",a,cb[tx]);
		else{
			cnt=cb[cfrom];
			tx-=cfrom;
			cnt+=caa*(tx/cs);
			cnt+=cb[cfrom+tx%cs]-cb[cfrom];
			printf("Case #%d: %lld\n",a,cnt);
		}
	}
	//system("pause");
    return 0;
}

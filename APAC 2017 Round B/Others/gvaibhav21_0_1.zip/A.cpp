#include<bits/stdc++.h>
using namespace std;
 
#define sd(mark) scanf("%d",&mark)
#define ss(mark) scanf("%s",&mark)
#define sl(mark) scanf("%lld",&mark)
#define debug(mark) printf("check%d\n",mark)
#define clr(mark) memset(mark,0,sizeof(mark))
#define F first
#define S second
#define MP make_pair
#define pb push_back
#define ll long long

int main()
{
	// freopen("A1.in","r",stdin);
	// freopen("A1.out","w",stdout);
	int t;
	sd(t);
	for(int tt=1;tt<=t;++tt)
	{
		ll l,r;
		sl(l);sl(r);
		l=min(l,r);
		l=l*(l+1)/2;
		printf("Case #%d: %lld\n",tt,l);
	}
}
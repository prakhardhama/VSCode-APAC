#include<bits/stdc++.h>
using namespace std;
 
#define sd(mark) scanf("%d",&mark)
#define ss(mark) scanf("%s",&mark)
#define sl(mark) scanf("%lld",&mark)
#define debug(mark) printf("check%d\n",mark)
#define clr(mark) memset(mark,0,sizeof(mark))
#define F first
#define S second
#define MP make_pair
#define PB push_back
#define ll long long
#define N 500010

vector<pair<int,int> > events;
set<int> sett;
pair<int,int> interval[N];
int Count[N];
int main()
{
	// freopen("C1.in","r",stdin);
	// freopen("C1.out","w",stdout);
	int t;
	sd(t);
	for(int tt=1;tt<=t;++tt)
	{
		cerr<<tt<<'\n';
		events.clear();
		sett.clear();
		clr(Count);
		ll n,L1,R1,A,B,C1,C2,M,i,j;
		sl(n);sl(L1);sl(R1);sl(A);sl(B);sl(C1);sl(C2);sl(M);	
		ll x=L1,y=R1;
		interval[0].F=L1;
		interval[0].S=R1;
		events.PB(MP(L1,1));
		events.PB(MP(R1+1,-1));

		for(i=1;i<n;++i)
		{
			interval[i].F=(A*x+B*y+C1)%M;
			interval[i].S=(A*y+B*x+C2)%M;
			x=interval[i].F;
			y=interval[i].S;
			interval[i].F=min(x,y);
			interval[i].S=max(x,y);
			events.PB(MP(interval[i].F,i+1));
			events.PB(MP(interval[i].S+1,-i-1));
			// printf("%lld %lld\n",x,y);
		}
		sort(events.begin(),events.end());
		int prev=0,ans=0;
		for(i=0;i<events.size();++i)
		{
			int cur=events[i].F;
			int pos=abs(events[i].S)-1;
			if((int)sett.size() > 0)
				ans=ans+cur-prev;
			if((int)sett.size() == 1)
				Count[*sett.begin()]+=(cur-prev);
			if(events[i].S < 0)
				sett.erase(pos);
			else
				sett.insert(pos);
			prev=cur;
		}
		int maxx=0;
		for(i=0;i<n;++i)
			maxx=max(maxx,Count[i]);
		printf("Case #%d: %d\n",tt,ans-maxx);
	}
}
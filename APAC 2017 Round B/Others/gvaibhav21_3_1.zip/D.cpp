#include<bits/stdc++.h>
using namespace std;
 
#define sd(mark) scanf("%d",&mark)
#define ss(mark) scanf("%s",&mark)
#define sl(mark) scanf("%lld",&mark)
#define debug(mark) printf("check%d\n",mark)
#define clr(mark) memset(mark,0,sizeof(mark))
#define F first
#define S second
#define MP make_pair
#define PB push_back
#define ll long long
#define N 5010

ll s1[N],s2[N],fact[N];
ll C[N][N];
ll dp[N];
int main()
{
	// freopen("D1.in","r",stdin);
	// freopen("D1.out","w",stdout);
	int t;
	sd(t);
	for(int tt=1;tt<=t;++tt)
	{
		cerr<<tt<<'\n';
		int n,M,i,j;
		sd(n);sd(M);
		//M=1000000000;
		fact[0]=1%M;
		
		for(i=1;i<=n;++i)
			fact[i]=fact[i-1]*i%M;

		C[0][0]=C[1][0]=C[1][1]=1%M;

		for(i=2;i<=n;++i)
		{
			C[i][0]=C[i][i]=1%M;
			for(j=1;j<i;++j)
				C[i][j]=(C[i-1][j-1]+C[i-1][j])%M;
		}

		dp[1]=1;
		for(i=2;i<=n;++i)
		{
			dp[i]=fact[i];
			for(j=1;j<i;++j)
				dp[i]=(dp[i]-(fact[i-j]*dp[j])%M + M)%M;
		}

		s1[1]=1%M;
		s2[1]=0;

		for(i=2;i<=n;++i)
		{
			s1[i]=dp[i];
			s2[i]=dp[i]*(dp[i]-1+M)%M;

			//cout<<i<<": "<<s1[i]<<' '<<s2[i]<<' ';
			for(j=1;j<i;++j)
			{

				ll S1=(s1[j]+fact[j])%M;
				ll S2=(s2[j] + (2*s1[j]*(fact[j]-1+M))%M + fact[j]*(fact[j]-1+M)%M)%M;
				ll X=dp[i-j];
				//cout<<i-j<<": ";
				ll S1_total=S1*X%M;
				ll S2_total=(S2*X%M + (S1*S1%M)*(X*(X-1+M)%M)%M)%M;
				//cout<<S1_total<<' '<<S2_total<<' ';
				s2[i]=(s2[i]+S2_total+(2ll*s1[i]*S1_total)%M)%M;
				s1[i]=(s1[i]+S1_total)%M;
				//cout<<s1[i]<<' '<<s2[i]<<' ';
			}
			//cout<<'\n';
		}
		//debug((int)s2[n]%M);
		printf("Case #%d: %lld\n",tt,(s1[n]*s1[n]%M-s2[n]+M)%M);
	
	}
}
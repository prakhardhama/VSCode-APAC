#include<stdio.h>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<map>
using namespace std;

long long int a[200005];
long long int tot=0,n;
long long int b[200005],small;

long long int cal(long long int index){
	long long int low=small,high=tot,mid,greater,equal,less,l1,eq1,i,j,ans;
	while(low<high)
	{
		j=0;
		less=0;
		equal=0;
		mid=(low+high)>>1;
		for(i=1;i<=n;i++)
		{
			while(j<i && (a[i]-a[j])>mid)
			{
				j++;
			}
			if(i!=j)
			{
				if((a[i]-a[j])==mid)
					less+=(i-j-1);
				else
					less+=(i-j);
			}
			if((a[i]-a[j])==mid)
				equal++;
		}
		if((less+equal)<index)
			low=mid+1;
		else
		{
			high=mid;
			l1=less;
			eq1=equal;
		}
	}
	ans=(index-l1)*low;
	j=0;
	for(i=1;i<=n;i++)
	{
		while(j<i && (a[i]-a[j])>low)
		{
			j++;
		}
		if(i!=j)
		{
			if((a[i]-a[j])<low)
			{
				ans=ans+(i-j)*a[i]-(b[i-1]-b[j-1]);
			}
			else
			{
				ans=ans+(i-j-1)*a[i]-(b[i-1]-b[j]);
			}
		}
	}
	return ans;
}

int main()
{
	freopen("in.txt","r",stdin);
	freopen("out.txt","w",stdout);

	long long int t,T,q,i,j,k,sum,l,r,ans;
	scanf("%lld",&T);
	for(t=1;t<=T;t++)
	{
		scanf("%lld %lld",&n,&q);
		a[0]=0;
		tot=0;
		
		small=200;
		for(i=1;i<=n;i++){
			scanf("%lld",&a[i]);
			small=min(small,a[i]);
			a[i]+=a[i-1];
			tot+=a[i];
			b[i]=tot;
		}
		printf("Case #%lld:\n",t);
		for(i=0;i<q;i++){
			scanf("%lld %lld",&l,&r);
			ans=cal(r)-cal(l-1);
			printf("%lld\n",ans);
		}
	}
	return 0;
}
